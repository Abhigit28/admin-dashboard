This directory is a placeholder for Reduk Framework extensions.
