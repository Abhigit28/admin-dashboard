<?php

    class Reduk_Customizer_Control_checkbox extends Reduk_Customizer_Control {
        public $type = "reduk-checkbox";
    }
    class Reduk_Customizer_Control_color_rgba extends Reduk_Customizer_Control {
        public $type = "reduk-color_rgba";
    }
    class Reduk_Customizer_Control_color extends Reduk_Customizer_Control {
        public $type = "reduk-color";
    }
    //class Reduk_Customizer_Control_raw extends Reduk_Customizer_Control {
    //    public $type = "reduk-raw";
    //}
    class Reduk_Customizer_Control_media extends Reduk_Customizer_Control {
        public $type = "reduk-media";
    }
    class Reduk_Customizer_Control_spinner extends Reduk_Customizer_Control {
        public $type = "reduk-spinner";
    }
    class Reduk_Customizer_Control_palette extends Reduk_Customizer_Control {
        public $type = "reduk-palette";
    }
    class Reduk_Customizer_Control_button_set extends Reduk_Customizer_Control {
        public $type = "reduk-button_set";
    }
    class Reduk_Customizer_Control_image_select extends Reduk_Customizer_Control {
        public $type = "reduk-image_select";
    }
    class Reduk_Customizer_Control_radio extends Reduk_Customizer_Control {
        public $type = "reduk-radio";
    }
    class Reduk_Customizer_Control_select extends Reduk_Customizer_Control {
        public $type = "reduk-select";
    }
    class Reduk_Customizer_Control_gallery extends Reduk_Customizer_Control {
        public $type = "reduk-gallery";
    }
    class Reduk_Customizer_Control_slider extends Reduk_Customizer_Control {
        public $type = "reduk-slider";
    }
    class Reduk_Customizer_Control_sortable extends Reduk_Customizer_Control {
        public $type = "reduk-sortable";
    }
    class Reduk_Customizer_Control_switch extends Reduk_Customizer_Control {
        public $type = "reduk-switch";
    }
    class Reduk_Customizer_Control_text extends Reduk_Customizer_Control {
        public $type = "reduk-text";
    }
    class Reduk_Customizer_Control_textarea extends Reduk_Customizer_Control {
        public $type = "reduk-textarea";
    }